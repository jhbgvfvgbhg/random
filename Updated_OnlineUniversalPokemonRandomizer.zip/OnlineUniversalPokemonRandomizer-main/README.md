# OnlineUniversalPokemonRandomizer
This is a quick port of Dabomstew's Universal Pokemon Randomizer to the web via CheerpJ.

It is identical to the jar file. The interface is awkward on mobile; I recorded a [demo of myself loading a file on mobile](https://youtube.com/watch?v=7wB2I31yrK4) to (hopefully) help.

As this is based on [Universal Pokemon Randomizer](https://github.com/Dabomstew/universal-pokemon-randomizer) instead of [Universal Pokemon Randomizer *ZX*](https://github.com/Ajarmar/universal-pokemon-randomizer-zx), it does not support the 3DS games; it supports DS and older.
